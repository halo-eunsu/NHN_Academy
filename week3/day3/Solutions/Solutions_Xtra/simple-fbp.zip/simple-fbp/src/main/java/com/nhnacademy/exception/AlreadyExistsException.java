package com.nhnacademy.exception;

public class AlreadyExistsException extends RuntimeException {

}
