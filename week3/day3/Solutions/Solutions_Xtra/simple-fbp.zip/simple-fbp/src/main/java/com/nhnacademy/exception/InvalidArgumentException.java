package com.nhnacademy.exception;

public class InvalidArgumentException extends RuntimeException {

}
