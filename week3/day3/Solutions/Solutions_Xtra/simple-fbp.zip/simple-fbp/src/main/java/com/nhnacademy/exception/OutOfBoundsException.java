package com.nhnacademy.exception;

public class OutOfBoundsException extends RuntimeException {

}
